namespace TestAdminLTE.Models
{
    public class ModelA
    {
        public string a1{set;get;}
        public string a2{set;get;}
    }
}