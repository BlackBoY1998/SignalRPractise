namespace TestAdminLTE.Models
{
    public class ModelB
    {
        public string b1{get;set;}
        public string b2{get;set;}
    }
}